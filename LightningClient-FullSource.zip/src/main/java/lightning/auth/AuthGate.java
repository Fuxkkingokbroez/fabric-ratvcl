/*
 * Decompiled with CFR 0.152.
 */
package lightning.auth;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public final class AuthGate {
    private static final String SERVER = "https://lightning-license-server-xaw3.onrender.com";
    private static final Path CRED_FILE = Paths.get(System.getProperty("user.home"), ".lightning", "credentials.properties");
    private static final Color BG = new Color(13, 18, 32);
    private static final Color PANEL = new Color(18, 26, 46);
    private static final Color FIELD_BG = new Color(10, 14, 26);
    private static final Color LINE = new Color(31, 42, 68);
    private static final Color CYAN = new Color(92, 225, 255);
    private static final Color VIOLET = new Color(139, 108, 255);
    private static final Color TEXT = new Color(230, 236, 255);
    private static final Color TEXT_DIM = new Color(123, 136, 168);
    private static final Color ERROR = new Color(255, 110, 110);
    private static final Font FONT_TITLE = new Font("Segoe UI", 1, 26);
    private static final Font FONT_LABEL = new Font("Segoe UI", 0, 13);
    private static final Font FONT_INPUT = new Font("Consolas", 0, 14);
    private static volatile String sessionToken;
    private static volatile boolean heartbeatRunning;

    private AuthGate() {
    }

    public static boolean verify() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception exception) {
            // empty catch block
        }
        AtomicReference<Object> atomicReference = new AtomicReference<Object>(null);
        Runnable runnable = () -> {
            Properties properties = AuthGate.loadSaved();
            String string = properties.getProperty("username");
            String string2 = properties.getProperty("licenseKey");
            String string3 = properties.getProperty("password");
            boolean bl = false;
            if (string != null && string2 != null && string3 != null) {
                try {
                    AuthResult authResult = AuthGate.callAuth(string, string3, string2);
                    if (authResult.ok) {
                        sessionToken = authResult.token;
                        bl = true;
                    }
                }
                catch (Throwable throwable) {}
            }
            if (!bl) {
                bl = AuthGate.showLoginDialog();
            }
            atomicReference.set(bl);
        };
        if (SwingUtilities.isEventDispatchThread()) {
            runnable.run();
        } else {
            try {
                SwingUtilities.invokeAndWait(runnable);
            }
            catch (Exception exception) {
                return false;
            }
        }
        Boolean bl = atomicReference.get();
        if (Boolean.TRUE.equals(bl)) {
            AuthGate.startHeartbeat();
            return true;
        }
        return false;
    }

    private static boolean showLoginDialog() {
        final JDialog jDialog = new JDialog((Frame)null, "Lightning Login", true);
        jDialog.setDefaultCloseOperation(0);
        jDialog.setResizable(false);
        jDialog.getContentPane().setBackground(BG);
        jDialog.setLayout(new BorderLayout());
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 1));
        jPanel.setBackground(BG);
        jPanel.setBorder(new EmptyBorder(28, 36, 24, 36));
        JLabel jLabel = new JLabel("\u26a1", 0);
        jLabel.setFont(new Font("Segoe UI Emoji", 0, 32));
        jLabel.setForeground(new Color(255, 216, 74));
        jLabel.setAlignmentX(0.5f);
        JLabel jLabel2 = new JLabel("LIGHTNING", 0);
        jLabel2.setFont(FONT_TITLE);
        jLabel2.setForeground(CYAN);
        jLabel2.setAlignmentX(0.5f);
        jLabel2.setBorder(new EmptyBorder(4, 0, 2, 0));
        JLabel jLabel3 = new JLabel("\u0110\u0103ng nh\u1eadp \u0111\u1ec3 ti\u1ebfp t\u1ee5c", 0);
        jLabel3.setFont(FONT_LABEL);
        jLabel3.setForeground(TEXT_DIM);
        jLabel3.setAlignmentX(0.5f);
        jLabel3.setBorder(new EmptyBorder(0, 0, 18, 0));
        jPanel.add(jLabel);
        jPanel.add(jLabel2);
        jPanel.add(jLabel3);
        Properties properties = AuthGate.loadSaved();
        JTextField jTextField = AuthGate.styledField(properties.getProperty("username", ""));
        JPasswordField jPasswordField = AuthGate.styledPasswordField();
        JTextField jTextField2 = AuthGate.styledField(properties.getProperty("licenseKey", ""));
        jPanel.add(AuthGate.fieldBlock("T\u00e0i kho\u1ea3n", jTextField));
        jPanel.add(Box.createVerticalStrut(12));
        jPanel.add(AuthGate.fieldBlock("M\u1eadt kh\u1ea9u", jPasswordField));
        jPanel.add(Box.createVerticalStrut(12));
        jPanel.add(AuthGate.fieldBlock("License Key", jTextField2));
        jPanel.add(Box.createVerticalStrut(16));
        final JLabel jLabel4 = new JLabel(" ", 0);
        jLabel4.setFont(FONT_LABEL);
        jLabel4.setForeground(ERROR);
        jLabel4.setAlignmentX(0.5f);
        jLabel4.setBorder(new EmptyBorder(0, 0, 10, 0));
        jPanel.add(jLabel4);
        final JButton jButton = AuthGate.pillButton("\u0110\u0103ng nh\u1eadp");
        jButton.setAlignmentX(0.5f);
        jPanel.add(jButton);
        jDialog.add((Component)jPanel, "Center");
        jDialog.getRootPane().setBorder(BorderFactory.createLineBorder(LINE, 1));
        jDialog.pack();
        jDialog.setSize(360, jDialog.getHeight());
        jDialog.setLocationRelativeTo(null);
        final boolean[] blArray = new boolean[]{false};
        ActionListener actionListener = actionEvent -> {
            final String string = jTextField.getText().trim();
            final String string2 = new String(jPasswordField.getPassword());
            final String string3 = jTextField2.getText().trim();
            if (string.isEmpty() || string2.isEmpty() || string3.isEmpty()) {
                jLabel4.setText("Vui l\u00f2ng \u0111i\u1ec1n \u0111\u1ee7 th\u00f4ng tin.");
                return;
            }
            jButton.setEnabled(false);
            jButton.setText("\u0110ang k\u1ebft n\u1ed1i...");
            jLabel4.setForeground(TEXT_DIM);
            jLabel4.setText("\u0110ang x\u00e1c th\u1ef1c, c\u00f3 th\u1ec3 m\u1ea5t t\u1edbi 1 ph\u00fat...");
            new SwingWorker<AuthResult, Void>(){

                @Override
                protected AuthResult doInBackground() {
                    return AuthGate.callAuth(string, string2, string3);
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                protected void done() {
                    AuthResult authResult;
                    try {
                        authResult = (AuthResult)this.get();
                    }
                    catch (Exception exception) {
                        authResult = AuthResult.error("L\u1ed7i kh\u00f4ng x\u00e1c \u0111\u1ecbnh: " + exception.getMessage());
                    }
                    if (!authResult.ok) {
                        jButton.setEnabled(true);
                        jButton.setText("\u0110\u0103ng nh\u1eadp");
                        jLabel4.setForeground(ERROR);
                        jLabel4.setText(authResult.message);
                        return;
                    }
                    sessionToken = authResult.token;
                    AuthGate.save(string, string3);
                    try {
                        Properties properties = AuthGate.loadSaved();
                        properties.setProperty("password", string2);
                        OutputStream outputStream = Files.newOutputStream(CRED_FILE, new OpenOption[0]);
                        properties.store(outputStream, "Lightning saved login (ghi nho dang nhap)");
                        outputStream.close();
                    }
                    catch (Throwable throwable) {}
                    blArray[0] = true;
                    jDialog.dispose();
                }
            }.execute();
        };
        jButton.addActionListener(actionListener);
        jPasswordField.addActionListener(actionListener);
        jTextField2.addActionListener(actionListener);
        jDialog.addWindowListener(new WindowAdapter(){

            @Override
            public void windowClosing(WindowEvent windowEvent) {
                int n = JOptionPane.showConfirmDialog(jDialog, "Tho\u00e1t game?", "X\u00e1c nh\u1eadn", 0);
                if (n == 0) {
                    blArray[0] = false;
                    jDialog.dispose();
                }
            }
        });
        jDialog.setVisible(true);
        return blArray[0];
    }

    private static JPanel fieldBlock(String string, JComponent jComponent) {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 1));
        jPanel.setBackground(BG);
        jPanel.setAlignmentX(0.5f);
        jPanel.setMaximumSize(new Dimension(280, 54));
        JLabel jLabel = new JLabel(string);
        jLabel.setFont(FONT_LABEL);
        jLabel.setForeground(TEXT_DIM);
        jLabel.setAlignmentX(0.0f);
        jLabel.setBorder(new EmptyBorder(0, 2, 4, 0));
        jComponent.setAlignmentX(0.0f);
        jPanel.add(jLabel);
        jPanel.add(jComponent);
        return jPanel;
    }

    private static JTextField styledField(String string) {
        JTextField jTextField = new JTextField(string);
        AuthGate.styleInput(jTextField);
        return jTextField;
    }

    private static JPasswordField styledPasswordField() {
        JPasswordField jPasswordField = new JPasswordField();
        AuthGate.styleInput(jPasswordField);
        return jPasswordField;
    }

    private static void styleInput(final JTextField jTextField) {
        jTextField.setFont(FONT_INPUT);
        jTextField.setBackground(FIELD_BG);
        jTextField.setForeground(TEXT);
        jTextField.setCaretColor(CYAN);
        jTextField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(LINE, 1), new EmptyBorder(7, 9, 7, 9)));
        jTextField.setMaximumSize(new Dimension(280, 32));
        jTextField.setPreferredSize(new Dimension(280, 32));
        jTextField.addFocusListener(new FocusAdapter(){

            @Override
            public void focusGained(FocusEvent focusEvent) {
                jTextField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(CYAN, 1), new EmptyBorder(7, 9, 7, 9)));
            }

            @Override
            public void focusLost(FocusEvent focusEvent) {
                jTextField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(LINE, 1), new EmptyBorder(7, 9, 7, 9)));
            }
        });
    }

    private static JButton pillButton(String string) {
        JButton jButton = new JButton(string){

            @Override
            protected void paintComponent(Graphics graphics) {
                Graphics2D graphics2D = (Graphics2D)graphics.create();
                graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradientPaint = new GradientPaint(0.0f, 0.0f, CYAN, this.getWidth(), 0.0f, VIOLET);
                graphics2D.setPaint(this.isEnabled() ? gradientPaint : new GradientPaint(0.0f, 0.0f, LINE, this.getWidth(), 0.0f, LINE));
                graphics2D.fillRoundRect(0, 0, this.getWidth(), this.getHeight(), 16, 16);
                graphics2D.dispose();
                super.paintComponent(graphics);
            }
        };
        jButton.setFont(new Font("Segoe UI", 1, 14));
        jButton.setForeground(new Color(10, 14, 26));
        jButton.setContentAreaFilled(false);
        jButton.setFocusPainted(false);
        jButton.setBorder(new EmptyBorder(9, 24, 9, 24));
        jButton.setMaximumSize(new Dimension(280, 38));
        jButton.setPreferredSize(new Dimension(280, 38));
        jButton.setCursor(Cursor.getPredefinedCursor(12));
        return jButton;
    }

    private static AuthResult callAuth(String string, String string2, String string3) {
        String string4 = "{\"username\":\"" + AuthGate.esc(string) + "\",\"password\":\"" + AuthGate.esc(string2) + "\",\"licenseKey\":\"" + AuthGate.esc(string3) + "\"}";
        try {
            HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(90L)).build();
            HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create("https://lightning-license-server-xaw3.onrender.com/auth")).timeout(Duration.ofSeconds(90L)).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(string4, StandardCharsets.UTF_8)).build();
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            String string5 = httpResponse.body();
            if (AuthGate.jsonBool(string5, "ok")) {
                String string6 = AuthGate.jsonString(string5, "token");
                return string6 != null ? AuthResult.ok(string6) : AuthResult.error("Ph\u1ea3n h\u1ed3i t\u1eeb server kh\u00f4ng h\u1ee3p l\u1ec7.");
            }
            String string7 = AuthGate.jsonString(string5, "reason");
            return AuthResult.error(AuthGate.reasonToMessage(string7));
        }
        catch (HttpTimeoutException httpTimeoutException) {
            return AuthResult.error("Server ph\u1ea3n h\u1ed3i qu\u00e1 l\u00e2u. Th\u1eed l\u1ea1i sau v\u00e0i gi\u00e2y.");
        }
        catch (Exception exception) {
            return AuthResult.error("Kh\u00f4ng k\u1ebft n\u1ed1i \u0111\u01b0\u1ee3c server: " + exception.getMessage());
        }
    }

    private static String reasonToMessage(String string) {
        if (string == null) {
            return "\u0110\u0103ng nh\u1eadp th\u1ea5t b\u1ea1i.";
        }
        return switch (string) {
            case "bad_credentials" -> "Sai t\u00e0i kho\u1ea3n ho\u1eb7c m\u1eadt kh\u1ea9u.";
            case "bad_key" -> "License key kh\u00f4ng \u0111\u00fang.";
            case "expired" -> "T\u00e0i kho\u1ea3n \u0111\u00e3 h\u1ebft h\u1ea1n.";
            case "account_disabled" -> "T\u00e0i kho\u1ea3n \u0111\u00e3 b\u1ecb kh\u00f3a.";
            case "ip_mismatch" -> "T\u00e0i kho\u1ea3n \u0111\u00e3 g\u00e1n v\u1edbi IP kh\u00e1c.";
            case "too_many_attempts" -> "Th\u1eed qu\u00e1 nhi\u1ec1u l\u1ea7n, \u0111\u1ee3i v\u00e0i ph\u00fat r\u1ed3i th\u1eed l\u1ea1i.";
            case "missing_fields" -> "Thi\u1ebfu th\u00f4ng tin \u0111\u0103ng nh\u1eadp.";
            default -> "\u0110\u0103ng nh\u1eadp th\u1ea5t b\u1ea1i (" + string + ").";
        };
    }

    private static void startHeartbeat() {
        if (heartbeatRunning) {
            return;
        }
        heartbeatRunning = true;
        Thread thread = new Thread(() -> {
            HttpClient httpClient = HttpClient.newHttpClient();
            while (true) {
                try {
                    while (true) {
                        HttpRequest httpRequest;
                        HttpResponse<String> httpResponse;
                        Thread.sleep(120000L);
                        if (sessionToken == null || AuthGate.jsonBool((httpResponse = httpClient.send(httpRequest = HttpRequest.newBuilder().uri(URI.create("https://lightning-license-server-xaw3.onrender.com/auth/heartbeat")).timeout(Duration.ofSeconds(30L)).header("Authorization", "Bearer " + sessionToken).POST(HttpRequest.BodyPublishers.noBody()).build(), HttpResponse.BodyHandlers.ofString())).body(), "ok")) continue;
                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, "Phi\u00ean \u0111\u0103ng nh\u1eadp kh\u00f4ng c\u00f2n h\u1ee3p l\u1ec7. Game s\u1ebd \u0111\u00f3ng.", "Lightning", 0));
                        System.exit(0);
                    }
                }
                catch (InterruptedException interruptedException) {
                    return;
                }
                catch (Exception exception) {
                    continue;
                }
                break;
            }
        }, "lightning-auth-heartbeat");
        thread.setDaemon(true);
        thread.start();
    }

    private static Properties loadSaved() {
        Properties properties = new Properties();
        try (InputStream inputStream = Files.newInputStream(CRED_FILE, new OpenOption[0]);){
            properties.load(inputStream);
        }
        catch (IOException iOException) {
            // empty catch block
        }
        return properties;
    }

    private static void save(String string, String string2) {
        try {
            Files.createDirectories(CRED_FILE.getParent(), new FileAttribute[0]);
            Properties properties = new Properties();
            properties.setProperty("username", string);
            properties.setProperty("licenseKey", string2);
            try (OutputStream outputStream = Files.newOutputStream(CRED_FILE, new OpenOption[0]);){
                properties.store(outputStream, "Lightning saved login (khong luu mat khau)");
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    private static String esc(String string) {
        return string.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static boolean jsonBool(String string, String string2) {
        Matcher matcher = Pattern.compile("\"" + string2 + "\"\\s*:\\s*(true|false)").matcher(string);
        return matcher.find() && matcher.group(1).equals("true");
    }

    private static String jsonString(String string, String string2) {
        Matcher matcher = Pattern.compile("\"" + string2 + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(string);
        if (!matcher.find()) {
            return null;
        }
        return matcher.group(1).replace("\\\"", "\"").replace("\\\\", "\\");
    }

    static {
        heartbeatRunning = false;
    }

    private static final class AuthResult {
        boolean ok;
        String token;
        String message;

        private AuthResult() {
        }

        static AuthResult ok(String string) {
            AuthResult authResult = new AuthResult();
            authResult.ok = true;
            authResult.token = string;
            return authResult;
        }

        static AuthResult error(String string) {
            AuthResult authResult = new AuthResult();
            authResult.ok = false;
            authResult.message = string;
            return authResult;
        }
    }
}

