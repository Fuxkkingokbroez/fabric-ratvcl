/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.google.gson.JsonPrimitive
 *  lombok.Generated
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.phys.Vec3
 */
package lightning.managers;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.lang.runtime.SwitchBootstraps;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.Collections;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.stream.Stream;
import lightning.Night;
import lightning.managers.WaypointManager;
import lightning.modules.Module;
import lightning.modules.impl.core.PingBypassModule;
import lightning.modules.impl.miscellaneous.FakePlayerModule;
import lightning.pingbypass.PingBypassFlags;
import lightning.settings.Setting;
import lightning.settings.impl.BindSetting;
import lightning.settings.impl.BooleanSetting;
import lightning.settings.impl.ColorSetting;
import lightning.settings.impl.ImageSetting;
import lightning.settings.impl.ModeSetting;
import lightning.settings.impl.NumberSetting;
import lightning.settings.impl.PositionSetting;
import lightning.settings.impl.StringSetting;
import lightning.settings.impl.WhitelistSetting;
import lightning.utils.minecraft.IdentifierUtils;
import lightning.utils.system.FileUtils;
import lombok.Generated;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;

public class ConfigManager {
    private String currentConfig = "default";
    private boolean loadingConfig = false;

    public ConfigManager() {
        this.loadConfig();
        Runtime.getRuntime().addShutdownHook(new Thread(this::saveConfig));
    }

    public void loadConfig() {
        block2: {
            try {
                this.migrateOldConfig();
                FileUtils.createDirectory("Lightning");
                FileUtils.createDirectory("Lightning/Configs");
                FileUtils.createDirectory("Lightning/Client");
                FileUtils.createDirectory("Lightning/Modules");
                FileUtils.createDirectory("Lightning/Binds");
                FileUtils.createDirectory("Lightning/Visuals");
                FileUtils.createDirectory("Lightning/GlobalConfigs");
                this.loadGeneral();
                this.loadWaypoints();
                this.loadModules(this.currentConfig);
            }
            catch (Exception exception) {
                Night.LOGGER.error("Failed to load the client's configuration!", (Throwable)exception);
                if (Night.CHAT_MANAGER == null) break block2;
                Night.CHAT_MANAGER.await("The configuration has not been loaded properly. Read the stacktrace for more information.");
            }
        }
    }

    private void migrateOldConfig() {
        try {
            Path path = Paths.get("EUClient", new String[0]);
            Path path2 = Paths.get("Lightning", new String[0]);
            if (!(!Files.exists(path, new LinkOption[0]) || Files.exists(path2, new LinkOption[0]) && Files.exists(path2.resolve("Configs"), new LinkOption[0]))) {
                Night.LOGGER.info("Migrating configuration from EUClient to Lightning...");
                ConfigManager.copyDirectory(path, path2);
            }
        }
        catch (Exception exception) {
            Night.LOGGER.warn("Failed to migrate old EUClient configuration: {}", (Object)exception.getMessage());
        }
    }

    private static void copyDirectory(Path path, Path path2) throws IOException {
        try (Stream<Path> stream = Files.walk(path, new FileVisitOption[0]);){
            stream.forEach(path3 -> {
                try {
                    Path path4 = path2.resolve(path.relativize((Path)path3));
                    if (Files.isDirectory(path3, new LinkOption[0])) {
                        if (!Files.exists(path4, new LinkOption[0])) {
                            Files.createDirectories(path4, new FileAttribute[0]);
                        }
                    } else if (!Files.exists(path4, new LinkOption[0])) {
                        if (path4.getParent() != null && !Files.exists(path4.getParent(), new LinkOption[0])) {
                            Files.createDirectories(path4.getParent(), new FileAttribute[0]);
                        }
                        Files.copy(path3, path4, StandardCopyOption.COPY_ATTRIBUTES);
                    }
                }
                catch (IOException iOException) {
                    Night.LOGGER.warn("Could not copy config file {}: {}", path3, (Object)iOException.getMessage());
                }
            });
        }
    }

    public void saveConfig() {
        try {
            FileUtils.createDirectory("Lightning");
            FileUtils.createDirectory("Lightning/Configs");
            FileUtils.createDirectory("Lightning/Client");
            FileUtils.createDirectory("Lightning/Modules");
            FileUtils.createDirectory("Lightning/Binds");
            FileUtils.createDirectory("Lightning/Visuals");
            FileUtils.createDirectory("Lightning/GlobalConfigs");
            this.saveGeneral();
            this.saveWaypoints();
            this.saveModules(this.currentConfig);
        }
        catch (IOException iOException) {
            Night.LOGGER.error("Failed to save the client's configuration!", (Throwable)iOException);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void loadWaypoints() throws IOException {
        if (!FileUtils.fileExists("Lightning/Waypoints.json")) {
            return;
        }
        InputStream inputStream = Files.newInputStream(Paths.get("Lightning/Waypoints.json", new String[0]), new OpenOption[0]);
        try {
            JsonObject jsonObject;
            try {
                jsonObject = JsonParser.parseReader((Reader)new InputStreamReader(inputStream)).getAsJsonObject();
            }
            catch (IllegalStateException illegalStateException) {
                Night.LOGGER.error("Failed to load the client's Waypoint configuration!", (Throwable)illegalStateException);
                Night.CHAT_MANAGER.await("The Waypoint configuration has not been loaded properly. Read the stacktrace for more information.");
                if (Collections.singletonList(inputStream).get(0) != null) {
                    inputStream.close();
                }
                if (Collections.singletonList(inputStream).get(0) != null) {
                    inputStream.close();
                }
                return;
            }
            if (jsonObject.has("Waypoints")) {
                for (JsonElement jsonElement : jsonObject.get("Waypoints").getAsJsonArray()) {
                    String[] stringArray = jsonElement.getAsString().split(":");
                    if (Night.WAYPOINT_MANAGER.contains(stringArray[0])) continue;
                    Night.WAYPOINT_MANAGER.add(stringArray[0], new Vec3((double)Integer.parseInt(stringArray[1]), (double)Integer.parseInt(stringArray[2]), (double)Integer.parseInt(stringArray[3])), stringArray[4], stringArray[5]);
                }
            }
        }
        finally {
            if (Collections.singletonList(inputStream).get(0) != null) {
                inputStream.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void loadGeneral() throws IOException {
        if (!FileUtils.fileExists("Lightning/General.json")) {
            return;
        }
        InputStream inputStream = Files.newInputStream(Paths.get("Lightning/General.json", new String[0]), new OpenOption[0]);
        try {
            JsonObject jsonObject;
            JsonElement jsonElement = JsonParser.parseReader((Reader)new InputStreamReader(inputStream));
            if (jsonElement == null || !jsonElement.isJsonObject()) {
                Night.LOGGER.warn("General.json is empty or invalid JSON.");
                return;
            }
            try {
                jsonObject = jsonElement.getAsJsonObject();
            }
            catch (Exception exception) {
                Night.LOGGER.error("Failed to load the client's General configuration!", (Throwable)exception);
                if (Night.CHAT_MANAGER != null) {
                    Night.CHAT_MANAGER.await("The General configuration has not been loaded properly. Read the stacktrace for more information.");
                }
                if (Collections.singletonList(inputStream).get(0) != null) {
                    inputStream.close();
                }
                return;
            }
            if (jsonObject.has("Config")) {
                this.currentConfig = jsonObject.get("Config").getAsString();
            }
            if (jsonObject.has("Prefix") && Night.COMMAND_MANAGER != null) {
                Night.COMMAND_MANAGER.setPrefix(jsonObject.get("Prefix").getAsString());
            }
            if (jsonObject.has("Friends") && Night.FRIEND_MANAGER != null) {
                for (JsonElement jsonElement2 : jsonObject.get("Friends").getAsJsonArray()) {
                    if (Night.FRIEND_MANAGER.contains(jsonElement2.getAsString())) continue;
                    Night.FRIEND_MANAGER.add(jsonElement2.getAsString());
                }
            }
            if (jsonObject.has("Macros") && Night.MACRO_MANAGER != null) {
                for (JsonElement jsonElement2 : jsonObject.get("Macros").getAsJsonArray()) {
                    try {
                        String[] stringArray = jsonElement2.getAsString().split(":", 2);
                        if (stringArray.length <= 1) continue;
                        int n = Integer.parseInt(stringArray[0]);
                        String string = stringArray[1];
                        Night.MACRO_MANAGER.add(string, n);
                    }
                    catch (NumberFormatException numberFormatException) {
                        Night.LOGGER.error("Failed to load the " + jsonElement2.getAsString() + " macro!", (Throwable)numberFormatException);
                        if (Night.CHAT_MANAGER == null) continue;
                        Night.CHAT_MANAGER.await("The " + jsonElement2.getAsString() + " macro has failed to load. Read the stacktrace for more information.");
                    }
                }
            }
        }
        finally {
            if (Collections.singletonList(inputStream).get(0) != null) {
                inputStream.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void saveGeneral() throws IOException {
        FileUtils.resetFile("Lightning/General.json");
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("Config", (JsonElement)new JsonPrimitive(this.currentConfig));
        jsonObject.add("Prefix", (JsonElement)new JsonPrimitive(Night.COMMAND_MANAGER.getPrefix()));
        JsonArray jsonArray = new JsonArray();
        Night.FRIEND_MANAGER.getFriends().forEach(string -> jsonArray.add(string));
        jsonObject.add("Friends", (JsonElement)jsonArray);
        JsonArray jsonArray2 = new JsonArray();
        Night.MACRO_MANAGER.getMacros().forEach((string, n) -> jsonArray2.add(n + ":" + string));
        jsonObject.add("Macros", (JsonElement)jsonArray2);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)new FileOutputStream("Lightning/General.json"), StandardCharsets.UTF_8);
        try {
            outputStreamWriter.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString((String)jsonObject.toString())));
        }
        finally {
            if (Collections.singletonList(outputStreamWriter).get(0) != null) {
                outputStreamWriter.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void saveWaypoints() throws IOException {
        FileUtils.resetFile("Lightning/Waypoints.json");
        JsonObject jsonObject = new JsonObject();
        JsonArray jsonArray = new JsonArray();
        for (WaypointManager.Waypoint waypoint : Night.WAYPOINT_MANAGER.getWaypoints()) {
            jsonArray.add(waypoint.getName() + ":" + (int)waypoint.getPos().x + ":" + (int)waypoint.getPos().y + ":" + (int)waypoint.getPos().z + ":" + waypoint.getDimension() + ":" + waypoint.getServer());
        }
        jsonObject.add("Waypoints", (JsonElement)jsonArray);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)new FileOutputStream("Lightning/Waypoints.json"), StandardCharsets.UTF_8);
        try {
            outputStreamWriter.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString((String)jsonObject.toString())));
        }
        finally {
            if (Collections.singletonList(outputStreamWriter).get(0) != null) {
                outputStreamWriter.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void loadModules(String string) throws IOException {
        if (!FileUtils.fileExists("Lightning/Configs/" + string + ".json")) {
            return;
        }
        InputStream inputStream = Files.newInputStream(Paths.get("Lightning/Configs/" + string + ".json", new String[0]), new OpenOption[0]);
        try {
            PingBypassModule pingBypassModule;
            JsonObject jsonObject;
            JsonElement jsonElement = JsonParser.parseReader((Reader)new InputStreamReader(inputStream));
            if (jsonElement == null || !jsonElement.isJsonObject()) {
                Night.LOGGER.warn("Module configuration is empty or invalid JSON: {}", (Object)string);
                return;
            }
            try {
                jsonObject = jsonElement.getAsJsonObject();
            }
            catch (Exception exception) {
                Night.LOGGER.error("Failed to load the client's Module configuration!", (Throwable)exception);
                if (Night.CHAT_MANAGER != null) {
                    Night.CHAT_MANAGER.await("The configuration for the Modules has not been loaded properly. Read the stacktrace for more information.");
                }
                if (Collections.singletonList(inputStream).get(0) != null) {
                    inputStream.close();
                }
                return;
            }
            if (!jsonObject.has("Modules")) {
                return;
            }
            JsonObject jsonObject2 = jsonObject.get("Modules").getAsJsonObject();
            this.loadingConfig = true;
            try {
                this.loadModulesInner(jsonObject2);
            }
            finally {
                this.loadingConfig = false;
            }
            this.currentConfig = string;
            try {
                this.saveGeneral();
            }
            catch (IOException iOException) {
                // empty catch block
            }
            if (PingBypassFlags.proxyForwardingActive && Night.PINGBYPASS_CONFIG != null && !Night.PINGBYPASS_CONFIG.isServer() && (pingBypassModule = Night.MODULE_MANAGER.getModule(PingBypassModule.class)) != null && pingBypassModule.isToggled()) {
                pingBypassModule.syncAllSettingsToProxy();
            }
        }
        finally {
            if (Collections.singletonList(inputStream).get(0) != null) {
                inputStream.close();
            }
        }
    }

    private void loadModulesInner(JsonObject jsonObject) {
        for (Module module : Night.MODULE_MANAGER.getModules()) {
            if (!jsonObject.has(module.getName())) {
                module.setToggled(false);
                module.resetValues();
                continue;
            }
            this.applyModuleJson(module, jsonObject.get(module.getName()).getAsJsonObject());
        }
    }

    public void applyModuleJson(Module module, JsonObject jsonObject) {
        this.applyModuleJson(module, jsonObject, true);
    }

    public void applyModuleJson(Module module, JsonObject jsonObject, boolean bl) {
        boolean bl2;
        boolean bl3 = bl2 = jsonObject.has("Status") && jsonObject.get("Status").getAsBoolean();
        if (!jsonObject.has("Settings")) {
            if (bl) {
                module.resetValues();
            }
            module.setToggled(bl2, false);
        } else {
            JsonObject jsonObject2 = jsonObject.get("Settings").getAsJsonObject();
            block22: for (Setting setting : module.getSettings()) {
                String[] stringArray;
                Setting setting2;
                Setting setting3;
                Object object;
                Setting setting4;
                Setting setting5;
                Setting setting6;
                Setting setting7;
                Setting setting8;
                if (!bl && setting instanceof BindSetting) continue;
                JsonElement jsonElement = jsonObject2.get(setting.getName());
                if (jsonElement != null && jsonElement.isJsonPrimitive()) {
                    Setting setting9;
                    setting8 = setting;
                    Objects.requireNonNull(setting8);
                    int n = 0;
                    switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{BooleanSetting.class, NumberSetting.class, ModeSetting.class, StringSetting.class, ImageSetting.class, BindSetting.class, ColorSetting.class, PositionSetting.class, WhitelistSetting.class}, (Setting)setting9, n)) {
                        case 0: {
                            setting7 = (BooleanSetting)setting9;
                            if (jsonElement.getAsJsonPrimitive().isBoolean()) {
                                ((BooleanSetting)setting7).setValue(jsonElement.getAsBoolean());
                                break;
                            }
                            ((BooleanSetting)setting7).resetValue();
                            break;
                        }
                        case 1: {
                            setting6 = (NumberSetting)setting9;
                            if (jsonElement.getAsJsonPrimitive().isNumber()) {
                                ((NumberSetting)setting6).setValue(jsonElement.getAsNumber());
                                break;
                            }
                            ((NumberSetting)setting6).resetValue();
                            break;
                        }
                        case 2: {
                            setting5 = (ModeSetting)setting9;
                            ((ModeSetting)setting5).setValue(jsonElement.getAsString());
                            break;
                        }
                        case 3: {
                            setting4 = (StringSetting)setting9;
                            object = jsonElement.getAsString();
                            if (object != null && ((String)object).equalsIgnoreCase("EUClient")) {
                                object = "Lightning";
                            }
                            ((StringSetting)setting4).setValue((String)object);
                            break;
                        }
                        case 4: {
                            setting3 = (ImageSetting)setting9;
                            ((ImageSetting)setting3).setValue(jsonElement.getAsString());
                            if (Night.IMAGE_MANAGER == null) break;
                            Night.IMAGE_MANAGER.setCurrentActiveImage(jsonElement.getAsString());
                            break;
                        }
                        case 5: {
                            setting2 = (BindSetting)setting9;
                            if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber()) {
                                ((BindSetting)setting2).setValue(jsonElement.getAsInt());
                                break;
                            }
                            stringArray = jsonElement.getAsString().split(",", 2);
                            ((BindSetting)setting2).setValue(Integer.parseInt(stringArray[0]));
                            if (stringArray.length <= 1) continue block22;
                            ((BindSetting)setting2).setMode(stringArray[1]);
                            break;
                        }
                        case 6: {
                            stringArray = (ColorSetting)setting9;
                            String[] stringArray2 = jsonElement.getAsString().split(",");
                            if (stringArray2.length != 6) break;
                            stringArray.setColor(new Color(Math.clamp((long)Integer.parseInt(stringArray2[0]), 0, 255), Math.clamp((long)Integer.parseInt(stringArray2[1]), 0, 255), Math.clamp((long)Integer.parseInt(stringArray2[2]), 0, 255), Math.clamp((long)Integer.parseInt(stringArray2[3]), 0, 255)));
                            stringArray.setSync(Boolean.parseBoolean(stringArray2[4]));
                            stringArray.setRainbow(Boolean.parseBoolean(stringArray2[5]));
                            break;
                        }
                        case 7: {
                            PositionSetting positionSetting = (PositionSetting)setting9;
                            String[] stringArray3 = jsonElement.getAsString().split(",");
                            if (stringArray3.length != 2) break;
                            positionSetting.set(Float.parseFloat(stringArray3[0]), Float.parseFloat(stringArray3[1]));
                            break;
                        }
                        case 8: {
                            WhitelistSetting whitelistSetting = (WhitelistSetting)setting9;
                            WhitelistSetting whitelistSetting2 = (WhitelistSetting)setting8;
                            whitelistSetting2.clear();
                            String[] stringArray4 = jsonElement.getAsString().split(",");
                            if (stringArray4.length == 0) break;
                            for (String string : stringArray4) {
                                Item item;
                                if (whitelistSetting2.getType() == WhitelistSetting.Type.ITEMS) {
                                    item = IdentifierUtils.getItem(string);
                                    if (item == null) continue;
                                    whitelistSetting2.add(item);
                                    continue;
                                }
                                if (whitelistSetting2.getType() != WhitelistSetting.Type.BLOCKS || (item = IdentifierUtils.getBlock(string)) == null) continue;
                                whitelistSetting2.add(item);
                            }
                            continue block22;
                        }
                    }
                    continue;
                }
                Objects.requireNonNull(setting);
                int n = 0;
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{BooleanSetting.class, NumberSetting.class, ModeSetting.class, StringSetting.class, ImageSetting.class, BindSetting.class, ColorSetting.class, WhitelistSetting.class, PositionSetting.class}, (Setting)setting8, n)) {
                    case 0: {
                        BooleanSetting booleanSetting = (BooleanSetting)setting8;
                        booleanSetting.resetValue();
                        break;
                    }
                    case 1: {
                        setting7 = (NumberSetting)setting8;
                        ((NumberSetting)setting7).resetValue();
                        break;
                    }
                    case 2: {
                        setting6 = (ModeSetting)setting8;
                        ((ModeSetting)setting6).resetValue();
                        break;
                    }
                    case 3: {
                        setting5 = (StringSetting)setting8;
                        ((StringSetting)setting5).resetValue();
                        break;
                    }
                    case 4: {
                        setting4 = (ImageSetting)setting8;
                        ((ImageSetting)setting4).resetValue();
                        break;
                    }
                    case 5: {
                        object = (BindSetting)setting8;
                        ((BindSetting)object).resetValue();
                        break;
                    }
                    case 6: {
                        setting3 = (ColorSetting)setting8;
                        ((ColorSetting)setting3).resetValue();
                        break;
                    }
                    case 7: {
                        setting2 = (WhitelistSetting)setting8;
                        ((WhitelistSetting)setting2).clear();
                        break;
                    }
                    case 8: {
                        stringArray = (PositionSetting)setting8;
                        stringArray.resetValue();
                        break;
                    }
                }
            }
            module.setToggled(bl2, false);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void saveModules(String string) throws IOException {
        FileUtils.resetFile("Lightning/Configs/" + string + ".json");
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("Config", (JsonElement)new JsonPrimitive(string));
        JsonObject jsonObject2 = new JsonObject();
        for (Module module : Night.MODULE_MANAGER.getModules()) {
            JsonObject jsonObject3 = this.serializeModuleJson(module);
            if (module instanceof FakePlayerModule) {
                jsonObject3.add("Status", (JsonElement)new JsonPrimitive(Boolean.valueOf(false)));
            }
            jsonObject2.add(module.getName(), (JsonElement)jsonObject3);
        }
        jsonObject.add("Modules", (JsonElement)jsonObject2);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)new FileOutputStream("Lightning/Configs/" + string + ".json"), StandardCharsets.UTF_8);
        try {
            outputStreamWriter.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString((String)jsonObject.toString())));
            this.currentConfig = string;
            try {
                this.saveGeneral();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        finally {
            if (Collections.singletonList(outputStreamWriter).get(0) != null) {
                outputStreamWriter.close();
            }
        }
    }

    public JsonObject serializeModuleJson(Module module) {
        return this.serializeModuleJson(module, true);
    }

    public JsonObject serializeModuleJson(Module module, boolean bl) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("Status", (JsonElement)new JsonPrimitive(Boolean.valueOf(module.isToggled())));
        JsonObject jsonObject2 = new JsonObject();
        for (Setting setting : module.getSettings()) {
            Setting setting2;
            if (!bl && setting instanceof BindSetting) continue;
            Setting setting3 = setting;
            Objects.requireNonNull(setting3);
            int n = 0;
            switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{BooleanSetting.class, NumberSetting.class, ModeSetting.class, StringSetting.class, ImageSetting.class, BindSetting.class, ColorSetting.class, WhitelistSetting.class, PositionSetting.class}, (Setting)setting2, n)) {
                case 0: {
                    BooleanSetting booleanSetting = (BooleanSetting)setting2;
                    jsonObject2.add(booleanSetting.getName(), (JsonElement)new JsonPrimitive(Boolean.valueOf(booleanSetting.getValue())));
                    break;
                }
                case 1: {
                    NumberSetting numberSetting = (NumberSetting)setting2;
                    jsonObject2.add(numberSetting.getName(), (JsonElement)new JsonPrimitive(numberSetting.getValue()));
                    break;
                }
                case 2: {
                    ModeSetting modeSetting = (ModeSetting)setting2;
                    jsonObject2.add(modeSetting.getName(), (JsonElement)new JsonPrimitive(modeSetting.getValue()));
                    break;
                }
                case 3: {
                    StringSetting stringSetting = (StringSetting)setting2;
                    jsonObject2.add(stringSetting.getName(), (JsonElement)new JsonPrimitive(stringSetting.getValue()));
                    break;
                }
                case 4: {
                    ImageSetting imageSetting = (ImageSetting)setting2;
                    jsonObject2.add(imageSetting.getName(), (JsonElement)new JsonPrimitive(imageSetting.getValue()));
                    break;
                }
                case 5: {
                    BindSetting bindSetting = (BindSetting)setting2;
                    jsonObject2.add(bindSetting.getName(), (JsonElement)new JsonPrimitive(bindSetting.getValue() + "," + bindSetting.getMode()));
                    break;
                }
                case 6: {
                    ColorSetting colorSetting = (ColorSetting)setting2;
                    jsonObject2.add(colorSetting.getName(), (JsonElement)new JsonPrimitive(colorSetting.getValue().getColor().getRed() + "," + colorSetting.getValue().getColor().getGreen() + "," + colorSetting.getValue().getColor().getBlue() + "," + colorSetting.getValue().getColor().getAlpha() + "," + colorSetting.isSync() + "," + colorSetting.isRainbow()));
                    break;
                }
                case 7: {
                    WhitelistSetting whitelistSetting = (WhitelistSetting)setting2;
                    StringJoiner stringJoiner = new StringJoiner(",");
                    for (String string : whitelistSetting.getWhitelistIds()) {
                        stringJoiner.add(string);
                    }
                    jsonObject2.add(whitelistSetting.getName(), (JsonElement)new JsonPrimitive(stringJoiner.toString()));
                    break;
                }
                case 8: {
                    PositionSetting positionSetting = (PositionSetting)setting2;
                    PositionSetting positionSetting2 = (PositionSetting)setting3;
                    jsonObject2.add(positionSetting2.getName(), (JsonElement)new JsonPrimitive(positionSetting2.getX() + "," + positionSetting2.getY()));
                    break;
                }
            }
        }
        jsonObject.add("Settings", (JsonElement)jsonObject2);
        return jsonObject;
    }

    @Generated
    public String getCurrentConfig() {
        return this.currentConfig;
    }

    @Generated
    public boolean isLoadingConfig() {
        return this.loadingConfig;
    }

    @Generated
    public void setCurrentConfig(String string) {
        this.currentConfig = string;
    }

    @Generated
    public void setLoadingConfig(boolean bl) {
        this.loadingConfig = bl;
    }
}

