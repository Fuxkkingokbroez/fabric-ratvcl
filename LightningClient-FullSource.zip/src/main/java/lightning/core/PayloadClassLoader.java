/*
 * Decompiled with CFR 0.152.
 */
package lightning.core;

import java.io.IOException;
import java.io.InputStream;
import lightning.core.AesCrypto;

final class PayloadClassLoader
extends ClassLoader {
    private final ClassLoader jarResourceLoader;
    private final byte[] key;

    PayloadClassLoader(ClassLoader classLoader, ClassLoader classLoader2, byte[] byArray) {
        super(classLoader);
        this.jarResourceLoader = classLoader2;
        this.key = byArray;
    }

    @Override
    protected Class<?> findClass(String string) throws ClassNotFoundException {
        Class<?> clazz;
        block9: {
            String string2 = string.replace('.', '/') + ".enc";
            InputStream inputStream = this.jarResourceLoader.getResourceAsStream(string2);
            try {
                if (inputStream == null) {
                    throw new ClassNotFoundException(string);
                }
                byte[] byArray = inputStream.readAllBytes();
                byte[] byArray2 = AesCrypto.decrypt(byArray, this.key);
                clazz = this.defineClass(string, byArray2, 0, byArray2.length);
                if (inputStream == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException iOException) {
                    throw new ClassNotFoundException(string, iOException);
                }
            }
            inputStream.close();
        }
        return clazz;
    }
}

