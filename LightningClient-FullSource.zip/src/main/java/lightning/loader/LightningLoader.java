/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint
 */
package lightning.loader;

import java.lang.reflect.Field;
import java.util.Map;
import javax.swing.JOptionPane;
import lightning.auth.AuthGate;
import lightning.loader.Injector;
import lightning.loader.Payload;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

public final class LightningLoader
implements PreLaunchEntrypoint {
    private static final String SERVER = "https://lightning-license-server-xaw3.onrender.com";

    public void onPreLaunch() {
        String string;
        System.setProperty("java.awt.headless", "false");
        if (!AuthGate.verify()) {
            System.exit(0);
        }
        if ((string = LightningLoader.readToken()) == null || string.isEmpty()) {
            LightningLoader.fail("\u0110\u0103ng nh\u1eadp xong nh\u01b0ng kh\u00f4ng l\u1ea5y \u0111\u01b0\u1ee3c phi\u00ean l\u00e0m vi\u1ec7c.", null);
            return;
        }
        try {
            Map<String, byte[]> map = Payload.fetch(SERVER, string);
            Injector.inject(LightningLoader.class.getClassLoader(), map);
        }
        catch (Payload.FetchException fetchException) {
            LightningLoader.fail(fetchException.getMessage(), fetchException);
        }
        catch (Throwable throwable) {
            LightningLoader.fail("Kh\u00f4ng t\u1ea3i \u0111\u01b0\u1ee3c module t\u1eeb server. Th\u1eed l\u1ea1i sau v\u00e0i gi\u00e2y.", throwable);
        }
    }

    private static String readToken() {
        try {
            Field field = AuthGate.class.getDeclaredField("sessionToken");
            field.setAccessible(true);
            Object object = field.get(null);
            return object == null ? null : object.toString();
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private static void fail(String string, Throwable throwable) {
        if (throwable != null) {
            throwable.printStackTrace();
        }
        try {
            JOptionPane.showMessageDialog(null, string, "Lightning", 0);
        }
        catch (Throwable throwable2) {
            // empty catch block
        }
        System.exit(1);
    }
}

